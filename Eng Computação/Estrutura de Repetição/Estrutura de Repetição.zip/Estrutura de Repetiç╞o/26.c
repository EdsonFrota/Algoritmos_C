#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main()
{
    setlocale(LC_ALL, "");

    int edson, junior;

    printf("TABUADA: ");
    scanf("%d", &junior);

    edson = 1;

    while(edson <= 10)
    {
        int f, s;

        f = edson;
        s = edson*junior;

        printf("\n\t%d x %d = %d\n", junior, f, s);
        edson = ++edson;
    }

    getch();
    return 0;


    system("pause");
}
