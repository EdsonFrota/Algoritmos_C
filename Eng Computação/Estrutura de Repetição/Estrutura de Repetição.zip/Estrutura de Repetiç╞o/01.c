#include<stdio.h>
#include<locale.h>

int main ()
{

    setlocale(LC_ALL, "");

    int edson;

    for (edson = 1; edson <= 1000; edson = ++edson)
    {

        printf("# EDSON J�NIOR FROTA SILVA #\n");  // MEU NOME
    }

    getch();
    return 0;
    system("pause");
}
